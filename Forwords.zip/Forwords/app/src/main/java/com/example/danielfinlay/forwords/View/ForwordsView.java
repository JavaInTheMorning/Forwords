package com.example.danielfinlay.forwords.View;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;

import com.example.danielfinlay.forwords.R;


/**
 * Created by danielfinlay on 3/16/18.
 */

public class ForwordsView extends View {
    private Bitmap bitmapBg = null;
    private Paint paintBackground;
    public ForwordsView (Context context,
                         @Nullable AttributeSet attrs) {
        super(context, attrs);

        bitmapBg = BitmapFactory.decodeResource(getResources(),
                R.drawable.forwords);
        paintBackground = new Paint();
        paintBackground.setColor(Color.WHITE);
        paintBackground.setStyle(Paint.Style.FILL);
    }
    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);

        bitmapBg = Bitmap.createScaledBitmap(bitmapBg,
                getWidth(), getHeight(), false);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        canvas.drawRect(0,
                0, getWidth(), getHeight(),
                paintBackground);

        canvas.drawBitmap(bitmapBg, 0, 0, null);


    }


}
